# WARYN Production

Production-grade Next.js scaffold for WARYN.

## Included
- Next.js 16 + React 19
- Supabase SSR Auth
- Protected dashboard
- WARYN AI Edge Function integration with 30-message server-side quota
- Resume analysis Edge Function integration
- Support tickets
- Admin-only finance dashboard
- Security headers and CSP
- Existing Supabase production schema with RLS

## Important: Payments
Apple Pay is intentionally NOT hard-coded. Activate it only after onboarding a merchant payment gateway account and adding server-side secrets + signed webhook verification.

## Deploy
1. Push the whole project to the connected GitHub repository.
2. In Vercel add:
   NEXT_PUBLIC_SUPABASE_URL
   NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
   NEXT_PUBLIC_APP_URL
3. Deploy from `main`.
4. Configure `OPENAI_API_KEY` in Supabase Edge Function secrets.
5. Configure payment provider secrets only after merchant onboarding.

## Security principles
- Never expose service role keys.
- Admin authorization uses `app_metadata`, not user-editable metadata.
- Sensitive quota and payment state must be server-side.
- Enable MFA for owner accounts.
- Keep CV storage private and use signed URLs when file upload is enabled.
- Run Supabase Security Advisor after every schema/security migration.
