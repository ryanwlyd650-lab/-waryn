"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function AIPage(){
  const [message,setMessage]=useState("");
  const [history,setHistory]=useState<{role:string,text:string}[]>([]);
  const [status,setStatus]=useState("");
  async function send(){
    const q=message.trim(); if(!q)return;
    setHistory(h=>[...h,{role:"user",text:q}]); setMessage(""); setStatus("يفكر...");
    const supabase=createClient();
    const {data,error}=await supabase.functions.invoke("waryn-ai",{body:{message:q}});
    if(error){setStatus("تعذر الاتصال بالمساعد.");return;}
    if(data?.error==="free_limit_reached"){setStatus("انتهت 30 رسالة المجانية. فعّل الاشتراك للمتابعة.");return;}
    setHistory(h=>[...h,{role:"ai",text:data?.reply||"تعذر توليد الرد."}]);setStatus("");
  }
  return <div className="stack">
    <div><span className="tag">30 Free Messages</span><h1>WARYN AI</h1><p className="lead">مساعد متخصص بالشبكات والأنظمة وCCNA وCloud والاستعداد الوظيفي.</p></div>
    <div className="panel" style={{minHeight:380}}>
      {history.map((m,i)=><div key={i} className="panel" style={{marginBottom:8,background:m.role==="user"?"#35dbc012":"#ffffff05"}}><b>{m.role==="user"?"أنت":"WARYN AI"}</b><div>{m.text}</div></div>)}
      {status&&<p className="lead">{status}</p>}
    </div>
    <textarea className="input" rows={4} value={message} onChange={e=>setMessage(e.target.value)} placeholder="اكتب سؤالك..." maxLength={4000}/>
    <button className="btn" onClick={send}>إرسال</button>
  </div>
}
