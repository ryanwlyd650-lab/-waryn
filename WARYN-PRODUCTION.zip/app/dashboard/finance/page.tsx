import { createClient } from "@/lib/supabase/server";

export default async function FinancePage(){
  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  const role=(user?.app_metadata as any)?.role;
  if(role!=="admin") return <div className="panel"><h1>المالية</h1><p className="lead">هذه الصفحة متاحة لحساب الإدارة فقط.</p></div>;
  const {data:rows}=await supabase.from("finance_ledger").select("occurred_at,entry_type,amount_sar,direction,description").order("occurred_at",{ascending:false}).limit(100);
  const incoming=(rows||[]).filter(x=>x.direction==="in").reduce((s,x)=>s+Number(x.amount_sar),0);
  const outgoing=(rows||[]).filter(x=>x.direction==="out").reduce((s,x)=>s+Number(x.amount_sar),0);
  return <div className="stack">
    <div><span className="tag">Admin Only</span><h1>Finance Dashboard</h1></div>
    <div className="grid3"><div className="metric panel"><span className="lead">الدخل</span><b>{incoming.toFixed(2)} SAR</b></div><div className="metric panel"><span className="lead">المصروف</span><b>{outgoing.toFixed(2)} SAR</b></div><div className="metric panel"><span className="lead">الصافي</span><b>{(incoming-outgoing).toFixed(2)} SAR</b></div></div>
    <div className="panel"><table className="table"><thead><tr><th>التاريخ</th><th>النوع</th><th>المبلغ</th><th>الاتجاه</th></tr></thead><tbody>{(rows||[]).map((r:any,i:number)=><tr key={i}><td>{new Date(r.occurred_at).toLocaleDateString("ar-SA")}</td><td>{r.entry_type}</td><td>{r.amount_sar}</td><td>{r.direction}</td></tr>)}</tbody></table></div>
  </div>
}
