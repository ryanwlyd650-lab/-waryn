import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { DashboardShell } from "@/components/dashboard-shell";

export default async function DashboardLayout({children}:{children:React.ReactNode}) {
  const supabase=await createClient();
  const {data}=await supabase.auth.getClaims();
  if(!data?.claims) redirect("/login");
  return <DashboardShell>{children}</DashboardShell>;
}
