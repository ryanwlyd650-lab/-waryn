import { createClient } from "@/lib/supabase/server";

export default async function DashboardPage(){
  const supabase=await createClient();
  const {data:{user}}=await supabase.auth.getUser();
  const {data:profile}=user?await supabase.from("profiles").select("display_name,plan,ai_messages_used,ai_free_limit").eq("user_id",user.id).single():{data:null};
  const used=profile?.ai_messages_used??0, limit=profile?.ai_free_limit??30;
  return <div className="stack">
    <div><span className="tag">Dashboard</span><h1>أهلًا {profile?.display_name||"بك في WARYN"}</h1><p className="lead">لوحتك للتعلم، الذكاء الاصطناعي، والسيرة المهنية.</p></div>
    <div className="grid3">
      <div className="metric panel"><span className="lead">رسائل AI</span><b>{used} / {limit}</b></div>
      <div className="metric panel"><span className="lead">الخطة</span><b>{profile?.plan||"free"}</b></div>
      <div className="metric panel"><span className="lead">Resume Review</span><b>30 SAR</b></div>
    </div>
  </div>
}
