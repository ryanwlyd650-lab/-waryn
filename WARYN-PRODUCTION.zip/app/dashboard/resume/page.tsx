"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function ResumePage(){
  const [resume,setResume]=useState("");
  const [job,setJob]=useState("");
  const [result,setResult]=useState<any>(null);
  const [status,setStatus]=useState("");
  async function analyze(){
    if(resume.trim().length<100){setStatus("الصق نص السيرة أولًا.");return;}
    setStatus("جارٍ التحليل بثلاث مراحل...");
    const supabase=createClient();
    const {data,error}=await supabase.functions.invoke("resume-analyze",{body:{resume_text:resume,job_description:job}});
    if(error||data?.error){setStatus("تعذر التحليل الآن.");return;}
    setResult(data.analysis);setStatus("");
  }
  return <div className="stack">
    <div><span className="tag">30 SAR • One free revision</span><h1>WARYN Resume</h1><p className="lead">النسخة الحالية توضح رحلة التحليل. فتح التحليل المدفوع سيتم بعد تفعيل Apple Pay من حساب التاجر.</p></div>
    <div className="grid2">
      <div className="panel stack">
        <textarea className="input" rows={14} value={resume} onChange={e=>setResume(e.target.value)} placeholder="الصق نص السيرة هنا..." maxLength={30000}/>
        <textarea className="input" rows={8} value={job} onChange={e=>setJob(e.target.value)} placeholder="وصف الوظيفة — اختياري" maxLength={15000}/>
        <button className="btn" onClick={analyze}>تحليل تجريبي للمستخدم المسجل</button>
        {status&&<p className="lead">{status}</p>}
      </div>
      <div className="panel">
        <h3>WARYN Resume Standard</h3>
        <p className="lead">ATS → Recruiter → Consistency / Truth Check</p>
        {result ? <div className="stack">
          <div className="grid3">
            <div className="metric"><span className="lead">Overall</span><b>{result.score??"--"}</b></div>
            <div className="metric"><span className="lead">ATS</span><b>{result.ats_score??"--"}</b></div>
            <div className="metric"><span className="lead">Consistency</span><b>{result.consistency_score??"--"}</b></div>
          </div>
          <p>{result.summary}</p>
          {Array.isArray(result.issues)&&<div><b>نقاط التحسين</b><ul>{result.issues.map((x:string,i:number)=><li key={i}>{x}</li>)}</ul></div>}
          {Array.isArray(result.missing_keywords)&&<div><b>Keywords ناقصة</b><p className="lead">{result.missing_keywords.join("، ")}</p></div>}
        </div> : <p className="lead">ستظهر نتيجة التحليل هنا.</p>}
      </div>
    </div>
  </div>
}
