"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function SupportPage(){
  const [subject,setSubject]=useState("");
  const [body,setBody]=useState("");
  const [status,setStatus]=useState("");
  async function createTicket(){
    const supabase=createClient();
    const {data:{user}}=await supabase.auth.getUser();
    if(!user){setStatus("سجل الدخول.");return;}
    const {data,error}=await supabase.from("support_tickets").insert({user_id:user.id,subject,category:"general"}).select("id").single();
    if(error){setStatus(error.message);return;}
    await supabase.from("support_messages").insert({ticket_id:data.id,sender_user_id:user.id,sender_type:"user",body});
    setStatus("تم فتح التذكرة بنجاح.");setSubject("");setBody("");
  }
  return <div className="stack">
    <div><span className="tag">Support</span><h1>الدعم</h1><p className="lead">أنشئ تذكرة، ثم يتم التعامل معها آليًا أو تصعيدها للإدارة.</p></div>
    <div className="panel stack">
      <input className="input" value={subject} onChange={e=>setSubject(e.target.value)} placeholder="عنوان المشكلة"/>
      <textarea className="input" rows={8} value={body} onChange={e=>setBody(e.target.value)} placeholder="اشرح المشكلة"/>
      <button className="btn" onClick={createTicket}>فتح تذكرة</button>
      {status&&<p className="lead">{status}</p>}
    </div>
  </div>
}
