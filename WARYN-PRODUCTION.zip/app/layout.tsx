import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "WARYN | وارِن",
  description: "منصة سعودية للتعلم التقني والذكاء الاصطناعي والجاهزية المهنية.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        <header className="wrap nav">
          <Link className="brand" href="/"><span className="logo">W</span> WARYN <span className="lead">| وارِن</span></Link>
          <div className="row">
            <Link className="btn btnGhost" href="/login">دخول</Link>
            <Link className="btn" href="/dashboard">لوحة التحكم</Link>
          </div>
        </header>
        {children}
      </body>
    </html>
  );
}
