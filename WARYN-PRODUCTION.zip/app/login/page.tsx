"use client";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [mode,setMode]=useState<"signin"|"signup">("signin");
  const [message,setMessage]=useState("");
  const router=useRouter();

  async function submit(){
    setMessage("جارٍ التنفيذ...");
    const supabase=createClient();
    const result = mode==="signup"
      ? await supabase.auth.signUp({email,password,options:{data:{name:email.split("@")[0]}}})
      : await supabase.auth.signInWithPassword({email,password});
    if(result.error){setMessage(result.error.message);return;}
    setMessage(mode==="signup"?"تم إنشاء الحساب. تحقق من بريدك إذا طُلب ذلك.":"تم تسجيل الدخول.");
    if(mode==="signin") router.push("/dashboard");
  }

  return <main className="wrap section">
    <div className="panel" style={{maxWidth:520,margin:"40px auto"}}>
      <span className="tag">WARYN Account</span><h1>{mode==="signin"?"تسجيل الدخول":"إنشاء حساب"}</h1>
      <div className="stack">
        <input className="input" type="email" placeholder="البريد الإلكتروني" value={email} onChange={e=>setEmail(e.target.value)} />
        <input className="input" type="password" placeholder="كلمة المرور" value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="btn" onClick={submit}>{mode==="signin"?"دخول":"إنشاء الحساب"}</button>
        <button className="btn btnGhost" onClick={()=>setMode(mode==="signin"?"signup":"signin")}>{mode==="signin"?"مستخدم جديد؟ إنشاء حساب":"عندي حساب بالفعل"}</button>
        {message && <p className="lead">{message}</p>}
      </div>
    </div>
  </main>
}
