import Link from "next/link";

export default function Home() {
  return (
    <main>
      <section className="wrap hero">
        <div>
          <span className="tag">🇸🇦 منصة سعودية للتقنية والبنية التحتية</span>
          <h1>تعلّم.<br/><span className="gradient">طبّق. وتوظّف.</span></h1>
          <p className="lead" style={{fontSize:18}}>WARYN تجمع التعلم العملي، المختبرات، الذكاء الاصطناعي، وتحسين السيرة المهنية في منصة واحدة.</p>
          <div className="row">
            <Link className="btn" href="/login">ابدأ الآن</Link>
            <Link className="btn btnGhost" href="/dashboard/resume">فحص السيرة — 30 ريال</Link>
          </div>
        </div>
        <div className="heroVisual"><div className="ring"/><div className="orb"/><div className="panel" style={{position:"absolute",bottom:20,left:20,right:20}}><b>WARYN AI</b><div className="lead">30 رسالة مجانية لكل حساب، ثم اشتراك.</div></div></div>
      </section>

      <section className="wrap section">
        <div className="grid3">
          <div className="panel"><span className="tag">Academy</span><h3>CCNA + Systems + Cloud</h3><p className="lead">مسارات منظمة من الأساسيات حتى الجاهزية المهنية.</p></div>
          <div className="panel"><span className="tag">Career</span><h3>Resume AI</h3><p className="lead">ATS + Recruiter Review + Consistency/Truth Check + إعادة واحدة.</p></div>
          <div className="panel"><span className="tag">Secure</span><h3>RLS + JWT + Server-side</h3><p className="lead">المنطق الحساس لا يعتمد على JavaScript عند العميل.</p></div>
        </div>
      </section>
    </main>
  );
}
