import Link from "next/link";
export function DashboardShell({children}:{children:React.ReactNode}) {
  return <main className="wrap dashboard">
    <aside className="panel sidebar">
      <Link className="sideLink" href="/dashboard">الرئيسية</Link>
      <Link className="sideLink" href="/dashboard/ai">WARYN AI</Link>
      <Link className="sideLink" href="/dashboard/resume">السيرة الذاتية</Link>
      <Link className="sideLink" href="/dashboard/support">الدعم</Link>
      <Link className="sideLink" href="/dashboard/finance">المالية</Link>
    </aside>
    <section>{children}</section>
  </main>
}
